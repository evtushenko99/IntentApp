package com.example.intentapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Map2Activity extends AppCompatActivity {
    private static final String SAVED_PARCEL = "PARCEL";
    private static final String SAVED_RECIEVED_PARCEL = "RECIVED_PARCEL";
    private final String TAG = this.getClass().getName();
    private TextView mGenerstedTextView;
    private TextView mRecievedTextView;
    private StringBuilder mStringBuilder;
    private Button mButton;
    private TestModel mTestModel;
    private TestModel mTestModel2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mStringBuilder = new StringBuilder();
        mTestModel = new TestModel();

        mGenerstedTextView = findViewById(R.id.map_text_view);
        mRecievedTextView = findViewById(R.id.map_message);
        mButton = findViewById(R.id.map_button);

        mButton.setOnClickListener(this::onClick);

        buildTestModelString(mTestModel);
        mGenerstedTextView.setText(mStringBuilder);
    }
    @Override
    protected void onStart() {
        super.onStart();
        if (getIntent().getExtras().getParcelable(SAVED_PARCEL) != null) {
            mTestModel2 = getIntent().getExtras().getParcelable(SAVED_PARCEL);
            buildTestModelString(mTestModel2);
            mRecievedTextView.setText(mStringBuilder);
        }
    }
    private void onClick(@NonNull View view) {
        Intent intent = new Intent(Map2Activity.this, Search3Activity.class);
        intent.putExtra(SAVED_PARCEL, mTestModel);
        startActivity(intent);
    }


    private void buildTestModelString(TestModel testModel) {
        mStringBuilder.delete(0, mStringBuilder.length());
        mStringBuilder.append(testModel.getString1());
        mStringBuilder.append(testModel.getString2());
        mStringBuilder.append(testModel.getObjectList1());
        mStringBuilder.append("\n");
        mStringBuilder.append(testModel.getObjectList2());
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(SAVED_PARCEL, mTestModel);
        outState.putParcelable(SAVED_RECIEVED_PARCEL, mTestModel2);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        mTestModel = savedInstanceState.getParcelable(SAVED_PARCEL);
        mTestModel2 = savedInstanceState.getParcelable(SAVED_RECIEVED_PARCEL);
        buildTestModelString(mTestModel);
        mGenerstedTextView.setText(mStringBuilder);
        buildTestModelString(mTestModel2);
        mRecievedTextView.setText(mStringBuilder);
    }

}

